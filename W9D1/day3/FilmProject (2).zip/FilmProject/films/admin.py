from django.contrib import admin
from .models import Country, Category
# Register your models here.

admin.site.register(Country)
admin.site.register(Category)