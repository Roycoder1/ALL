list1 = [5, 10, 15, 20, 25, 50, 20]

idx = list1.index(20)

print(idx)

list1[idx] = 200

print(list1)