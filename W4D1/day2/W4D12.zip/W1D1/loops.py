# for i in range(0, 100, 2):
#     print(i)

# for i in range(100):
#     print(i)

run_times = 5

for iteration in range(run_times):
    print("Hello")


for character in "A WORD":
    print(character)